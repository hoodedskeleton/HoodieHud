=====================================================
How to install the hud:

1.) Go to C:\Users\[Your Name]\AppData\Roaming\Diabotical
2.) Edit "Settings.txt" with something like Notepad++
3.) Search within the text file for "hud_definition ="
4.) Replace ONLY that line with all of the text in "hoodiehud.txt"
5.) Boot up the game and enjoy!


=====================================================
It didn't work and now I have a totally blank hud!

Make sure you didn't move hud_crosshair_stroke_width = 3 (line 81) or hud_fps = 0 (line 83).


=====================================================
Changelog:

v1.0 -	Initial release.

v1.1 -	Changed health color from blue to green.
	Added invisible G-Meter for Enable direction hints (in More Settings).

v1.2 -	Fixed health bar not turning red on low health.
	Changed low health value from 30 to 40.