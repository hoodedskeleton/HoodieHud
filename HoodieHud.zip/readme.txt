How to install the hud:

1.) Go to C:\Users\[Your Name]\AppData\Roaming\Diabotical
2.) Edit "Settings.txt" with something like Notepad++
3.) Search within the text file for "hud_definition ="
4.) Replace ONLY that line with all of the text in "hoodiehud.txt"
5.) Boot up the game and enjoy! The health colors are set to my custom team color, so you'll probably want to adjust that.


It didn't work and now I have a totally blank hud!

Make sure you didn't move hud_crosshair_stroke_width = 3 (line 81) or hud_fps = 0 (line 83).